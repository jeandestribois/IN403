GRAPHE dijkstra(GRAPHE station, SKIEUR skieur, int *IDpere);

int itineraire(GRAPHE chemin, SKIEUR skieur, int *IDpere);